from base_agent import BaseAgent
import sys, json

class DataAgent(BaseAgent):
    def run(self, input_data):
        return {
            "processed": True,
            "original": input_data,
            "summary": f"Length: {len(str(input_data))}"
        }

if __name__ == "__main__":
    data = json.loads(sys.argv[1])
    agent = DataAgent("DataAgent")
    print(json.dumps(agent.run(data)))

from base_agent import BaseAgent
import sys, json

class ReportAgent(BaseAgent):
    def run(self, input_data):
        return {
            "report": f"Report generated: {input_data}"
        }

if __name__ == "__main__":
    data = json.loads(sys.argv[1])
    agent = ReportAgent("ReportAgent")
    print(json.dumps(agent.run(data)))

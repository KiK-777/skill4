from base_agent import BaseAgent
import sys, json

class AuditAgent(BaseAgent):
    def run(self, input_data):
        risk = "low"
        if "amount" in input_data and input_data["amount"] > 10000:
            risk = "high"

        return {
            "audit": True,
            "risk_level": risk
        }

if __name__ == "__main__":
    data = json.loads(sys.argv[1])
    agent = AuditAgent("AuditAgent")
    print(json.dumps(agent.run(data)))

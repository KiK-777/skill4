const express = require('express')
const bodyParser = require('body-parser')
const { dispatchTask } = require('./agentManager')

const app = express()
app.use(bodyParser.json())

app.post('/task', async (req, res) => {
    const { type, data } = req.body

    try {
        const result = await dispatchTask(type, data)
        res.json({ success: true, result: JSON.parse(result) })
    } catch (err) {
        res.status(500).json({ success: false, error: err.message })
    }
})

app.listen(3000, () => {
    console.log('Multi-Agent System running on port 3000')
})

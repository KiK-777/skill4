const { exec } = require('child_process')

function runAgent(script, input) {
    return new Promise((resolve, reject) => {
        const process = exec(`python ${script} '${JSON.stringify(input)}'`)

        process.stdout.on('data', data => {
            resolve(data.toString())
        })

        process.stderr.on('data', err => {
            reject(err.toString())
        })
    })
}

async function dispatchTask(type, data) {
    switch (type) {
        case 'data':
            return await runAgent('../agents/data_agent.py', data)

        case 'audit':
            return await runAgent('../agents/audit_agent.py', data)

        case 'report':
            return await runAgent('../agents/report_agent.py', data)

        default:
            throw new Error('Unknown task type')
    }
}

module.exports = { dispatchTask }
